package it.unimib.datai.nanofaas.controlplane.service;

import it.unimib.datai.nanofaas.common.model.ExecutionMode;
import it.unimib.datai.nanofaas.common.model.FunctionSpec;
import it.unimib.datai.nanofaas.common.model.InvocationRequest;
import it.unimib.datai.nanofaas.common.model.InvocationResult;
import it.unimib.datai.nanofaas.controlplane.dispatch.DispatchResult;
import it.unimib.datai.nanofaas.controlplane.dispatch.DispatcherRouter;
import it.unimib.datai.nanofaas.controlplane.execution.ExecutionRecord;
import it.unimib.datai.nanofaas.controlplane.execution.ExecutionState;
import it.unimib.datai.nanofaas.controlplane.execution.ExecutionStore;
import it.unimib.datai.nanofaas.controlplane.scheduler.InvocationKind;
import it.unimib.datai.nanofaas.controlplane.scheduler.InvocationTask;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExecutionCompletionHandlerTest {

    @Mock private InvocationEnqueuer enqueuer;
    @Mock private Metrics metrics;
    @Mock private DispatcherRouter dispatcherRouter;
    @Mock private DeploymentWakeUpGate wakeUpGate;

    private ExecutionStore executionStore;
    private ExecutionCompletionHandler completionHandler;

    private FunctionSpec testSpec;

    @BeforeEach
    void setUp() {
        executionStore = new ExecutionStore();
        completionHandler = new ExecutionCompletionHandler(executionStore, enqueuer, dispatcherRouter, metrics, wakeUpGate);

        testSpec = new FunctionSpec(
                "testFunc", "test-image", null, null, null,
                30000, 4, 100, 3, null, ExecutionMode.LOCAL, null, null, null
        );

        io.micrometer.core.instrument.simple.SimpleMeterRegistry meterRegistry =
                new io.micrometer.core.instrument.simple.SimpleMeterRegistry();
        when(metrics.latency(anyString())).thenReturn(
                io.micrometer.core.instrument.Timer.builder("test-latency").register(meterRegistry));
        when(metrics.queueWait(anyString())).thenReturn(
                io.micrometer.core.instrument.Timer.builder("test-queue-wait").register(meterRegistry));
        when(metrics.e2eLatency(anyString())).thenReturn(
                io.micrometer.core.instrument.Timer.builder("test-e2e").register(meterRegistry));
        when(metrics.initDuration(anyString())).thenReturn(
                io.micrometer.core.instrument.Timer.builder("test-init").register(meterRegistry));
        when(metrics.timers(anyString())).thenAnswer(invocation -> new Metrics.FunctionTimers(
                metrics.latency(invocation.getArgument(0)),
                metrics.initDuration(invocation.getArgument(0)),
                metrics.queueWait(invocation.getArgument(0)),
                metrics.e2eLatency(invocation.getArgument(0))
        ));
    }

    // ─── dispatch tests ────────────────────────────────────────────────────────

    @Test
    void dispatch_whenExecutionRecordMissing_releasesSlotAndSkipsRouter() {
        InvocationTask missingTask = new InvocationTask(
                "missing-exec", "fn",
                functionSpec("fn", ExecutionMode.LOCAL),
                new InvocationRequest("payload", Map.of()),
                null, null, Instant.now(), 1
        ,
        InvocationKind.SYNC
    );

        completionHandler.dispatch(missingTask);

        verify(enqueuer).releaseDispatchSlot("fn");
        verifyNoInteractions(dispatcherRouter);
    }

    @Test
    void dispatch_whenExecutionAlreadyTerminal_releasesSlotAndSkipsRouter() {
        InvocationTask task = task("exec-timeout-before-dispatch", "local-fn", ExecutionMode.LOCAL);
        ExecutionRecord executionRecord = new ExecutionRecord(task.executionId(), task);
        executionStore.put(executionRecord);
        executionRecord.markTimeout();

        completionHandler.dispatch(task);

        verify(enqueuer).releaseDispatchSlot("local-fn");
        verifyNoInteractions(dispatcherRouter);
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.TIMEOUT);
    }

    @Test
    void dispatch_whenRouterThrowsSynchronously_completesExecutionWithError() throws Exception {
        InvocationTask task = task("exec-1", "local-fn", ExecutionMode.LOCAL);
        ExecutionRecord executionRecord = new ExecutionRecord(task.executionId(), task);
        executionStore.put(executionRecord);

        when(dispatcherRouter.dispatchLocal(any())).thenThrow(new RuntimeException("router down"));

        assertThatCode(() -> completionHandler.dispatch(task)).doesNotThrowAnyException();

        InvocationResult result = executionRecord.completion().get(1, TimeUnit.SECONDS);
        assertThat(result.success()).isFalse();
        assertThat(result.error().code()).isEqualTo("LOCAL_ERROR");
        assertThat(result.error().message()).contains("router down");
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.ERROR);
        verify(enqueuer).releaseDispatchSlot("local-fn");
    }

    @Test
    void dispatch_poolMode_routesToPoolDispatcherAndCompletesSuccess() throws Exception {
        InvocationTask task = task("exec-2", "pool-fn", ExecutionMode.EXTERNAL);
        ExecutionRecord executionRecord = new ExecutionRecord(task.executionId(), task);
        executionStore.put(executionRecord);

        when(dispatcherRouter.dispatchExternal(any())).thenReturn(
                CompletableFuture.completedFuture(DispatchResult.warm(InvocationResult.success("ok"))));

        completionHandler.dispatch(task);

        InvocationResult result = executionRecord.completion().get(1, TimeUnit.SECONDS);
        assertThat(result.success()).isTrue();
        assertThat(result.output()).isEqualTo("ok");
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.SUCCESS);
        verify(dispatcherRouter).dispatchExternal(task);
        verifyNoInteractions(wakeUpGate);
    }

    @Test
    void dispatch_deploymentWaitsForWakeUpBeforeRoutingExternally() throws Exception {
        InvocationTask task = task("exec-deployment", "deployment-fn", ExecutionMode.DEPLOYMENT);
        ExecutionRecord executionRecord = new ExecutionRecord(task.executionId(), task);
        executionStore.put(executionRecord);
        CompletableFuture<Void> wakeUp = new CompletableFuture<>();
        when(wakeUpGate.ensureReady(task)).thenReturn(wakeUp);
        when(dispatcherRouter.dispatchExternal(task)).thenReturn(
                CompletableFuture.completedFuture(DispatchResult.warm(InvocationResult.success("ok"))));

        completionHandler.dispatch(task);

        verify(wakeUpGate).ensureReady(task);
        verify(dispatcherRouter, never()).dispatchExternal(task);
        wakeUp.complete(null);

        assertThat(executionRecord.completion().get(1, TimeUnit.SECONDS).success()).isTrue();
        verify(dispatcherRouter).dispatchExternal(task);
    }

    @Test
    void dispatch_deploymentWakeUpFailureCompletesWithDistinctErrorWithoutRouting() throws Exception {
        FunctionSpec deploymentSpec = functionSpec("deployment-fn", ExecutionMode.DEPLOYMENT, 0);
        InvocationTask task = new InvocationTask(
                "exec-deployment-failure", "deployment-fn", deploymentSpec,
                new InvocationRequest("payload", Map.of()), null, null, Instant.now(), 1,
                InvocationKind.SYNC
            );
        ExecutionRecord executionRecord = new ExecutionRecord(task.executionId(), task);
        executionStore.put(executionRecord);
        CompletableFuture<Void> failedWakeUp = new CompletableFuture<>();
        failedWakeUp.completeExceptionally(new IllegalStateException("DEPLOYMENT_WAKE_UP_TIMEOUT"));
        when(wakeUpGate.ensureReady(task)).thenReturn(failedWakeUp);

        completionHandler.dispatch(task);

        InvocationResult result = executionRecord.completion().get(1, TimeUnit.SECONDS);
        assertThat(result.success()).isFalse();
        assertThat(result.error().code()).isEqualTo("DEPLOYMENT_WAKE_UP_FAILED");
        assertThat(result.error().message()).contains("DEPLOYMENT_WAKE_UP_TIMEOUT");
        verify(dispatcherRouter, never()).dispatchExternal(task);
    }

    // ─── completeExecution / retry tests ──────────────────────────────────────

    @Test
    void completeExecution_withRetry_doesNotCompleteTheFuture() {
        ExecutionRecord executionRecord = recordInStore("exec-retry", testSpec, "idem-key");
        when(enqueuer.enqueue(any())).thenReturn(true);

        completionHandler.completeExecution("exec-retry", InvocationResult.error("ERROR", "First attempt failed"));

        assertThat(executionRecord.completion().isDone()).isFalse();
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.QUEUED);
        assertThat(executionRecord.task().attempt()).isEqualTo(2);
        verify(enqueuer, times(1)).enqueue(any());
        verify(enqueuer).releaseDispatchSlot("testFunc");
    }

    @Test
    void completeExecution_afterMaxRetries_completesTheFuture() {
        ExecutionRecord executionRecord = recordInStore("exec-max", testSpec, null);
        when(enqueuer.enqueue(any())).thenReturn(true);

        // Attempt 1
        completionHandler.completeExecution("exec-max", InvocationResult.error("ERROR", "Attempt 1 failed"));
        assertThat(executionRecord.completion().isDone()).isFalse();
        assertThat(executionRecord.task().attempt()).isEqualTo(2);

        // Attempt 2
        completionHandler.completeExecution("exec-max", InvocationResult.error("ERROR", "Attempt 2 failed"));
        assertThat(executionRecord.completion().isDone()).isFalse();
        assertThat(executionRecord.task().attempt()).isEqualTo(3);

        // Attempt 3
        completionHandler.completeExecution("exec-max", InvocationResult.error("ERROR", "Attempt 3 failed"));
        assertThat(executionRecord.completion().isDone()).isFalse();
        assertThat(executionRecord.task().attempt()).isEqualTo(4);

        // Attempt 4 (initial attempt + maxRetries=3)
        completionHandler.completeExecution("exec-max", InvocationResult.error("ERROR", "Attempt 4 failed"));

        assertThat(executionRecord.completion().isDone()).isTrue();
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.ERROR);
        verify(enqueuer, times(4)).releaseDispatchSlot("testFunc");
    }

    @Test
    void completeExecution_withSuccess_completesImmediately() {
        ExecutionRecord executionRecord = recordInStore("exec-ok", testSpec, null);

        completionHandler.completeExecution("exec-ok", InvocationResult.success("result"));

        assertThat(executionRecord.completion().isDone()).isTrue();
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.SUCCESS);
        assertThat(executionRecord.output()).isEqualTo("result");
        verify(enqueuer).releaseDispatchSlot("testFunc");
    }

    @Test
    void completeExecution_withSuccess_readsFieldsUnderLockWithoutSnapshot() {
        CountingExecutionRecord executionRecord = countingRecordInStore("exec-count", testSpec);

        completionHandler.completeExecution("exec-count", InvocationResult.success("result"));

        assertThat(executionRecord.snapshotReads()).isZero();
        // Two readers, one each: the completion path computing the durations, and the store's
        // terminal listener checking whether this record has a conclusion left to record.
        assertThat(executionRecord.finishedAtNanosReads()).isEqualTo(2);
    }

    @Test
    void completeExecution_afterTimeout_doesNotOverwriteTimeoutOrEmitSuccessMetrics() {
        ExecutionRecord executionRecord = recordInStore("exec-timeout", testSpec, null);
        executionRecord.markRunning();
        executionRecord.markTimeout();

        completionHandler.completeExecution("exec-timeout", InvocationResult.success("late-result"));

        assertThat(executionRecord.state()).isEqualTo(ExecutionState.TIMEOUT);
        assertThat(executionRecord.output()).isNull();
        verify(metrics, never()).success("testFunc");
        verify(metrics, never()).error("testFunc");
    }

    @Test
    void retry_preservesExecutionId() {
        ExecutionRecord executionRecord = recordInStore("exec-preserve", testSpec, null);
        when(enqueuer.enqueue(any())).thenReturn(true);

        completionHandler.completeExecution("exec-preserve", InvocationResult.error("ERROR", "Failed"));

        assertThat(executionRecord.executionId()).isEqualTo("exec-preserve");
        assertThat(executionRecord.task().executionId()).isEqualTo("exec-preserve");
    }

    @Test
    void retry_clearsIdempotencyKey() {
        InvocationTask taskWithKey = new InvocationTask(
                "exec-idem", "testFunc", testSpec,
                new InvocationRequest("payload", null),
                "my-idempotency-key", null, Instant.now(), 1
        ,
        InvocationKind.SYNC
    );
        ExecutionRecord executionRecord = new ExecutionRecord("exec-idem", taskWithKey);
        executionStore.put(executionRecord);
        when(enqueuer.enqueue(any())).thenReturn(true);

        assertThat(executionRecord.task().idempotencyKey()).isEqualTo("my-idempotency-key");

        completionHandler.completeExecution("exec-idem", InvocationResult.error("ERROR", "Failed"));

        assertThat(executionRecord.task().idempotencyKey()).isNull();
    }

    // ─── queue-full retry tests ────────────────────────────────────────────────

    @Test
    void retryWithQueueFull_completesFutureWithError() {
        when(enqueuer.enqueue(any())).thenReturn(false);
        ExecutionRecord executionRecord = recordInStore("exec-qfull", testSpec, null);

        completionHandler.completeExecution("exec-qfull", InvocationResult.error("ERROR", "First attempt failed"));

        assertThat(executionRecord.completion().isDone()).isTrue();
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.ERROR);
        InvocationResult result = executionRecord.completion().join();
        assertThat(result.success()).isFalse();
        assertThat(result.error().code()).isEqualTo("ERROR");
        verify(enqueuer).releaseDispatchSlot("testFunc");
    }

    @Test
    void retryWithQueueFull_afterSuccessfulRetries_completesFuture() {
        when(enqueuer.enqueue(any()))
                .thenReturn(true)   // first retry succeeds
                .thenReturn(false); // second retry queue full
        ExecutionRecord executionRecord = recordInStore("exec-mixed", testSpec, null);

        // First failure → retry (attempt 2)
        completionHandler.completeExecution("exec-mixed", InvocationResult.error("ERROR", "Attempt 1"));
        assertThat(executionRecord.completion().isDone()).isFalse();
        assertThat(executionRecord.task().attempt()).isEqualTo(2);

        // Second failure → retry attempt but queue full
        completionHandler.completeExecution("exec-mixed", InvocationResult.error("ERROR", "Attempt 2"));

        assertThat(executionRecord.completion().isDone()).isTrue();
        assertThat(executionRecord.state()).isEqualTo(ExecutionState.ERROR);
        verify(enqueuer, times(2)).releaseDispatchSlot("testFunc");
    }

    // ─── helpers ──────────────────────────────────────────────────────────────

    private ExecutionRecord recordInStore(String executionId, FunctionSpec spec, String idempotencyKey) {
        InvocationTask task = new InvocationTask(
                executionId, spec.name(), spec,
                new InvocationRequest("payload", null),
                idempotencyKey, null, Instant.now(), 1
        ,
        InvocationKind.SYNC
    );
        ExecutionRecord executionRecord = new ExecutionRecord(executionId, task);
        executionStore.put(executionRecord);
        return executionRecord;
    }

    private InvocationTask task(String executionId, String functionName, ExecutionMode mode) {
        return new InvocationTask(
                executionId, functionName, functionSpec(functionName, mode),
                new InvocationRequest("payload", Map.of()),
                null, null, Instant.now(), 1
        ,
        InvocationKind.SYNC
    );
    }

    private FunctionSpec functionSpec(String functionName, ExecutionMode mode) {
        return functionSpec(functionName, mode, 1);
    }

    private FunctionSpec functionSpec(String functionName, ExecutionMode mode, int maxRetries) {
        return new FunctionSpec(
                functionName, "image", null, Map.of(), null,
                1000, 1, 10, maxRetries, null, mode, null, null, null
        );
    }

    private CountingExecutionRecord countingRecordInStore(String executionId, FunctionSpec spec) {
        InvocationTask task = new InvocationTask(
                executionId, spec.name(), spec,
                new InvocationRequest("payload", null),
                null, null, Instant.now(), 1
        ,
        InvocationKind.SYNC
    );
        CountingExecutionRecord executionRecord = new CountingExecutionRecord(executionId, task);
        executionStore.put(executionRecord);
        return executionRecord;
    }

    private static final class CountingExecutionRecord extends ExecutionRecord {
        private final AtomicInteger snapshotReads = new AtomicInteger();
        private final AtomicInteger finishedAtNanosReads = new AtomicInteger();

        private CountingExecutionRecord(String executionId, InvocationTask task) {
            super(executionId, task);
        }

        @Override
        public synchronized Snapshot snapshot() {
            snapshotReads.incrementAndGet();
            return super.snapshot();
        }

        @Override
        public synchronized Long finishedAtNanos() {
            finishedAtNanosReads.incrementAndGet();
            return super.finishedAtNanos();
        }

        int snapshotReads() {
            return snapshotReads.get();
        }

        int finishedAtNanosReads() {
            return finishedAtNanosReads.get();
        }
    }
}
