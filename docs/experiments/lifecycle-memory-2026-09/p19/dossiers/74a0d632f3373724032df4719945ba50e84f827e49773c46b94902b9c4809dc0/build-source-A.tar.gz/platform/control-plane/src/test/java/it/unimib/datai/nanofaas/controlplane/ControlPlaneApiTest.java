package it.unimib.datai.nanofaas.controlplane;

import it.unimib.datai.nanofaas.common.model.ExecutionMode;
import it.unimib.datai.nanofaas.common.model.FunctionSpec;
import it.unimib.datai.nanofaas.common.model.InvocationRequest;
import it.unimib.datai.nanofaas.controlplane.registry.FunctionService;
import it.unimib.datai.nanofaas.controlplane.service.RateLimiter;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.health.actuate.endpoint.HealthEndpoint;
import org.springframework.boot.webtestclient.autoconfigure.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
        properties = {
                "nanofaas.rate.maxPerSecond=1000",
                "nanofaas.defaults.timeoutMs=2000",
                "nanofaas.defaults.concurrency=2",
                "nanofaas.defaults.queueSize=10",
                "nanofaas.defaults.maxRetries=3",
                "nanofaas.registry.path=build/test-control-plane-api-functions.json",
                "sync-queue.enabled=false"
        })
@AutoConfigureWebTestClient
class ControlPlaneApiTest {
    @Autowired
    private WebTestClient webTestClient;

    @Autowired
    private FunctionService functionService;

    @Autowired
    private RateLimiter rateLimiter;

    @Autowired
    private MeterRegistry meterRegistry;

    @Autowired
    private HealthEndpoint healthEndpoint;

    @BeforeEach
    void setup() {
        functionService.remove("echo");
        functionService.register(new FunctionSpec(
                "echo",
                "local",
                null,
                Map.of(),
                null,
                1000,
                1,
                10,
                3,
                null,
                ExecutionMode.LOCAL,
                null,
                null,
                null
        ));
    }

    @Test
    void issue006_rateLimitAndRouting() {
        rateLimiter.setMaxPerSecond(0);

        webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .bodyValue(new InvocationRequest("one", Map.of()))
                .exchange()
                .expectStatus().isEqualTo(429);

        rateLimiter.setMaxPerSecond(1000);

        webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .bodyValue(new InvocationRequest("two", Map.of()))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void issue007_idempotencyReturnsSameExecutionId() {
        rateLimiter.setMaxPerSecond(1000);

        Map<String, Object> body1 = webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .header("Idempotency-Key", "abc")
                .bodyValue(new InvocationRequest("payload", Map.of()))
                .exchange()
                .expectStatus().isOk()
                .expectBody(Map.class)
                .returnResult()
                .getResponseBody();

        Map<String, Object> body2 = webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .header("Idempotency-Key", "abc")
                .bodyValue(new InvocationRequest("payload", Map.of()))
                .exchange()
                .expectStatus().isOk()
                .expectBody(Map.class)
                .returnResult()
                .getResponseBody();

        assertNotNull(body1);
        assertNotNull(body2);
        assertEquals(body1.get("executionId"), body2.get("executionId"));
    }

    @Test
    void issue009_schedulerCompletesLocalInvocation() {
        rateLimiter.setMaxPerSecond(1000);

        Map<String, Object> body = webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .bodyValue(new InvocationRequest("payload", Map.of()))
                .exchange()
                .expectStatus().isOk()
                .expectBody(Map.class)
                .returnResult()
                .getResponseBody();

        assertNotNull(body);
        String executionId = body.get("executionId").toString();

        await().atMost(5, TimeUnit.SECONDS).untilAsserted(() ->
                webTestClient.get()
                        .uri("/v1/executions/{id}", executionId)
                        .exchange()
                        .expectStatus().isOk()
                        .expectBody()
                        .jsonPath("$.status").isEqualTo("success"));
    }

    @Test
    void issue013_syncWaitReturnsOutput() {
        rateLimiter.setMaxPerSecond(1000);

        webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .bodyValue(new InvocationRequest("payload", Map.of()))
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo("success")
                .jsonPath("$.output").isEqualTo("payload");
    }

    @Test
    void issue017_prometheusMetricsExposed() {
        webTestClient.post()
                .uri("/v1/functions/echo:invoke")
                .bodyValue(new InvocationRequest("payload", Map.of()))
                .exchange()
                .expectStatus().isOk();

        assertNotNull(meterRegistry.find("function_dispatch_total").counter());
    }

    @Test
    void issue018_healthEndpointIsUp() {
        assertEquals("UP", healthEndpoint.health().getStatus().getCode());
    }
}
