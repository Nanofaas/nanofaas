package it.unimib.datai.nanofaas.controlplane.service;

import it.unimib.datai.nanofaas.controlplane.scheduler.InvocationKind;

import it.unimib.datai.nanofaas.common.model.ExecutionMode;
import it.unimib.datai.nanofaas.common.model.FunctionSpec;
import it.unimib.datai.nanofaas.common.model.InvocationRequest;
import it.unimib.datai.nanofaas.common.model.InvocationResponse;
import it.unimib.datai.nanofaas.common.model.RuntimeMode;
import it.unimib.datai.nanofaas.controlplane.execution.ExecutionStore;
import it.unimib.datai.nanofaas.controlplane.execution.IdempotencyStore;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

class ReactiveInvocationCoordinatorTest {

    private final ExecutionStore executionStore = new ExecutionStore();
    private final IdempotencyStore idempotencyStore = new IdempotencyStore();
    private final Metrics metrics = new Metrics(new SimpleMeterRegistry());
    private final InvocationExecutionFactory factory =
            new InvocationExecutionFactory(executionStore, idempotencyStore, metrics);
    private final ExecutionCompletionHandler completionHandler = mock(ExecutionCompletionHandler.class);
    private final ReactiveInvocationCoordinator coordinator =
            new ReactiveInvocationCoordinator(null, metrics, null, null, completionHandler, new InvocationResponseMapper());

    @Test
    void clientTimeoutDoesNotCancelSharedCompletionFuture() {
        FunctionSpec spec = spec("fn-cancel");
        InvocationExecutionFactory.ExecutionLookup lookup =
                factory.createOrReuseExecution("fn-cancel", spec, new InvocationRequest("payload", Map.of()), null, null, InvocationKind.SYNC);

        SyncInvocation invocation = coordinator.invoke(lookup, spec, 50).block();

        assertThat(invocation).isNotNull();
        InvocationResponse response = invocation.response();
        assertThat(response.status()).isEqualTo("timeout");
        // The shared future must survive a single client's timeout: other idempotent
        // waiters and the completion callback still depend on it.
        assertThat(lookup.executionRecord().completion().isCancelled()).isFalse();
    }

    @Test
    void aClientTimeoutDoesNotSettleTheRecordWhileItsDispatchIsStillInFlight() {
        FunctionSpec spec = spec("fn-slot");
        InvocationExecutionFactory.ExecutionLookup lookup =
                factory.createOrReuseExecution("fn-slot", spec, new InvocationRequest("p", Map.of()), null, null, InvocationKind.SYNC);
        String executionId = lookup.executionRecord().executionId();

        coordinator.invoke(lookup, spec, 50).block();

        // The dispatch still holds a concurrency slot, and the one that gives it back is
        // the completion, which looks for the record among the living. Archiving it here
        // would make it unreachable and the slot would stay taken forever.
        assertThat(executionStore.getOrNull(executionId)).isNotNull();
        assertThat(executionStore.outcomeOf(executionId)).isNull();
    }

    @Test
    void exceptionalCompletionYieldsErrorResponseNotTimeout() {
        FunctionSpec spec = spec("fn-boom");
        InvocationExecutionFactory.ExecutionLookup lookup =
                factory.createOrReuseExecution("fn-boom", spec, new InvocationRequest("p", Map.of()), null, null, InvocationKind.SYNC);
        lookup.executionRecord().completion().completeExceptionally(new RuntimeException("boom"));

        SyncInvocation invocation = coordinator.invoke(lookup, spec, 1000).block();

        assertThat(invocation).isNotNull();
        InvocationResponse response = invocation.response();
        assertThat(response.status()).isEqualTo("error");
        assertThat(response.error().code()).isEqualTo("EXECUTION_FAILED");
    }

    private static FunctionSpec spec(String name) {
        return new FunctionSpec(name, "img", List.of(), Map.of(), null,
                1000, 1, 10, 0, null, ExecutionMode.LOCAL, RuntimeMode.HTTP, null, null, null);
    }
}
