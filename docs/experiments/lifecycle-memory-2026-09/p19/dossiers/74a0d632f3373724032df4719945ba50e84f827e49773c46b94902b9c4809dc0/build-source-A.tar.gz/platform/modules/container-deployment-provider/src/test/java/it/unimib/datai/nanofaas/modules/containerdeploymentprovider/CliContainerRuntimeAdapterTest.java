package it.unimib.datai.nanofaas.modules.containerdeploymentprovider;

import it.unimib.datai.nanofaas.common.model.ResourceQuantity;
import it.unimib.datai.nanofaas.common.model.ResourceSpec;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class CliContainerRuntimeAdapterTest {

    @Test
    void isAvailable_returnsFalseWhenVersionCommandFails() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.failure(1, "missing runtime"));
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("nerdctl", executor);

        assertThat(adapter.isAvailable()).isFalse();
        assertThat(executor.commands()).containsExactly(List.of("nerdctl", "version"));
    }

    @Test
    void runContainer_buildsDockerCompatibleCommand() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.success(""))
                .withResult(ExecutionResult.success(""));
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("podman", executor);

        adapter.runContainer(new ContainerInstanceSpec(
                "nanofaas-echo-r1",
                "img:latest",
                18080,
                List.of("java", "-jar", "app.jar"),
                new LinkedHashMap<>(Map.of(
                        "FUNCTION_NAME", "echo",
                        "WARM", "true"
                )),
                new ResourceSpec(
                        new ResourceQuantity(new BigDecimal("0.25"), 256),
                        new ResourceQuantity(BigDecimal.ONE, 512)
                ),
                null
        ));

        assertThat(executor.commands()).containsExactly(
                List.of("podman", "rm", "-f", "nanofaas-echo-r1"),
                List.of(
                        "podman", "run", "-d",
                        "--name", "nanofaas-echo-r1",
                        "-p", "18080:8080",
                        "--cpu-shares", "256",
                        "--cpus", "1",
                        "--memory-reservation", "256m",
                        "--memory", "512m",
                        "-e", "FUNCTION_NAME=echo",
                        "-e", "WARM=true",
                        "img:latest",
                        "java", "-jar", "app.jar"
                )
        );
    }

    @Test
    void runContainer_omitsRedundantMemoryReservation() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor();
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("docker", executor);

        adapter.runContainer(instance(new ResourceSpec(
                new ResourceQuantity(null, 256),
                new ResourceQuantity(null, 256)
        )));

        assertThat(executor.commands().get(1))
                .contains("--memory", "256m")
                .doesNotContain("--memory-reservation");
    }

    @Test
    void runContainer_withoutResources_omitsResourceFlags() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor();
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("docker", executor);

        adapter.runContainer(instance(null));

        assertThat(executor.commands().get(1))
                .doesNotContain("--cpu-shares", "--cpus", "--memory-reservation", "--memory");
    }

    private static ContainerInstanceSpec instance(ResourceSpec resources) {
        return new ContainerInstanceSpec("fn-r1", "img", 18080, List.of(), Map.of(), resources, null);
    }

    private static final class RecordingCliCommandExecutor implements CliCommandExecutor {
        private final List<List<String>> commands = new ArrayList<>();
        private final List<ExecutionResult> results = new ArrayList<>();

        RecordingCliCommandExecutor withResult(ExecutionResult result) {
            results.add(result);
            return this;
        }

        List<List<String>> commands() {
            return commands;
        }

        @Override
        public ExecutionResult run(List<String> command) {
            commands.add(List.copyOf(command));
            if (results.isEmpty()) {
                return ExecutionResult.success("");
            }
            return results.removeFirst();
        }
    }

    @Test
    void pinsEveryContainerToTheSharedCoreSetWhenOneIsConfigured() {
        // A per-function CPU limit caps each container separately, so on a host with spare cores
        // the functions never compete: two with four CPUs each on an eleven-core machine barely
        // affected one another. Sharing a core set is what makes capacity a quantity they divide.
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.success(""))
                .withResult(ExecutionResult.success(""));
        CliContainerRuntimeAdapter adapter =
                new CliContainerRuntimeAdapter("docker", executor, "0-3");

        adapter.runContainer(new ContainerInstanceSpec(
                "nanofaas-echo-r1", "img:latest", 18080, List.of(), Map.of(), null, null));

        assertThat(executor.commands().get(1)).containsSequence("--cpuset-cpus", "0-3");
    }

    @Test
    void leavesTheCoreSetAloneWhenNoneIsConfigured() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.success(""))
                .withResult(ExecutionResult.success(""));
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("docker", executor);

        adapter.runContainer(new ContainerInstanceSpec(
                "nanofaas-echo-r1", "img:latest", 18080, List.of(), Map.of(), null, null));

        assertThat(executor.commands().get(1)).doesNotContain("--cpuset-cpus");
    }

    @Test
    void runContainer_passesOwnershipLabels() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.success(""))
                .withResult(ExecutionResult.success(""));
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("docker", executor);

        adapter.runContainer(new ContainerInstanceSpec(
                "nanofaas-echo-r1", "img:latest", 18080, List.of(), Map.of(), null,
                Map.of(
                        ContainerLocalDeploymentProvider.MANAGED_LABEL, "true",
                        ContainerLocalDeploymentProvider.FUNCTION_LABEL, "echo",
                        ContainerLocalDeploymentProvider.REPLICA_LABEL, "1")
        ));

        assertThat(executor.commands().get(1)).containsSubsequence(
                "--label", "io.nanofaas.function=echo",
                "--label", "io.nanofaas.managed=true",
                "--label", "io.nanofaas.replica=1"
        );
    }

    @Test
    void listManagedContainers_returnsRunningAndStoppedOwnedReplicasWithIndexAndHostPort() {
        RecordingCliCommandExecutor executor = new RecordingCliCommandExecutor()
                .withResult(ExecutionResult.success("nanofaas-echo-r1\trunning\nnanofaas-echo-r2\texited\n"))
                .withResult(ExecutionResult.success("0.0.0.0:31001"));
        CliContainerRuntimeAdapter adapter = new CliContainerRuntimeAdapter("docker", executor);

        assertThat(adapter.listManagedContainers("echo")).containsExactly(
                new ManagedContainer("nanofaas-echo-r1", 1, 31001, true),
                new ManagedContainer("nanofaas-echo-r2", 2, null, false)
        );

        assertThat(executor.commands()).containsExactly(
                List.of(
                        "docker", "ps", "-a",
                        "--filter", "label=io.nanofaas.managed=true",
                        "--filter", "label=io.nanofaas.function=echo",
                        "--format", "{{.Names}}\t{{.State}}"),
                List.of("docker", "port", "nanofaas-echo-r1", "8080/tcp")
        );
    }
}