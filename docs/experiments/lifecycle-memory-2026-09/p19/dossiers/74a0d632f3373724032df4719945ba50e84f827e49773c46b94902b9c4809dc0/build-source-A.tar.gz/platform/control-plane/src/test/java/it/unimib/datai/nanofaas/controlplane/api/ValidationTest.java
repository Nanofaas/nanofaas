package it.unimib.datai.nanofaas.controlplane.api;

import it.unimib.datai.nanofaas.common.model.ExecutionMode;
import it.unimib.datai.nanofaas.common.model.FunctionSpec;
import it.unimib.datai.nanofaas.common.model.InvocationRequest;
import it.unimib.datai.nanofaas.controlplane.registry.DeploymentMetadata;
import it.unimib.datai.nanofaas.controlplane.registry.FunctionService;
import it.unimib.datai.nanofaas.controlplane.service.InvocationService;
import it.unimib.datai.nanofaas.controlplane.registry.FunctionNotFoundException;
import it.unimib.datai.nanofaas.controlplane.registry.RegisteredFunction;
import it.unimib.datai.nanofaas.controlplane.service.RateLimiter;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webflux.test.autoconfigure.WebFluxTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@WebFluxTest(controllers = {FunctionController.class, InvocationController.class})
@Import({GlobalExceptionHandler.class, RateLimiter.class})
class ValidationTest {

    @Autowired
    private WebTestClient webClient;

    @MockitoBean
    private FunctionService functionService;

    @MockitoBean
    private InvocationService invocationService;

    @Test
    void register_withBlankName_returns400() {
        FunctionSpec spec = new FunctionSpec(
                "",  // blank name
                "myimage",
                null, null, null, null, null, null, null, null,
                ExecutionMode.DEPLOYMENT, null, null, null
        );

        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(spec)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.details").isArray();
    }

    @Test
    void register_withNullImage_returns400() {
        FunctionSpec spec = new FunctionSpec(
                "myfunc",
                null,  // null image
                null, null, null, null, null, null, null, null,
                ExecutionMode.DEPLOYMENT, null, null, null
        );

        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(spec)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("VALIDATION_ERROR");
    }

    @Test
    void register_withZeroConcurrency_returns400() {
        FunctionSpec spec = new FunctionSpec(
                "myfunc",
                "myimage",
                null, null, null, null,
                0,  // zero concurrency
                null, null, null,
                ExecutionMode.DEPLOYMENT, null, null, null
        );

        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(spec)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.details[0]").value(s -> ((String) s).contains("concurrency"));
    }

    @Test
    void register_withNonPositiveResource_returns400() {
        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                        {"name":"myfunc","image":"myimage","resources":{"limits":{"cpu":0}}}
                        """)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.details[0]").value(s -> ((String) s).contains("resources.limits.cpu"));
    }

    @Test
    void register_withCpuPrecisionAboveMillicores_returns400() {
        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                        {"name":"myfunc","image":"myimage","resources":{"limits":{"cpu":0.0001}}}
                        """)
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void register_withResourceRequestAboveLimit_returns400() {
        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                        {
                          "name":"myfunc",
                          "image":"myimage",
                          "resources":{
                            "requests":{"cpu":1,"memoryMiB":513},
                            "limits":{"cpu":0.5,"memoryMiB":512}
                          }
                        }
                        """)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.details[0]").value(s -> ((String) s).contains("request must not exceed limit"));
    }

    @Test
    void register_withLegacyResourceFormat_returns400() {
        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("""
                        {"name":"myfunc","image":"myimage","resources":{"cpu":"250m","memory":"256Mi"}}
                        """)
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void register_withValidSpec_returns201() {
        FunctionSpec spec = new FunctionSpec(
                "myfunc",
                "myimage",
                null, null, null, null, null, null, null, null,
                ExecutionMode.DEPLOYMENT, null, null, null
        );

        when(functionService.register(any())).thenReturn(Optional.of(new RegisteredFunction(
                spec,
                new DeploymentMetadata(
                        ExecutionMode.DEPLOYMENT,
                        ExecutionMode.DEPLOYMENT,
                        "k8s",
                        null
                )
        )));

        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(spec)
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.requestedExecutionMode").isEqualTo("DEPLOYMENT")
                .jsonPath("$.effectiveExecutionMode").isEqualTo("DEPLOYMENT");
    }

    @Test
    void invoke_withNullInput_returns400() {
        InvocationRequest request = new InvocationRequest(null, null);

        webClient.post()
                .uri("/v1/functions/myfunc:invoke")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.details[0]").value(s -> ((String) s).contains("input"));
    }

    @Test
    void invoke_withValidRequest_callsService() {
        InvocationRequest request = new InvocationRequest("payload", null);

        when(invocationService.invokeSyncReactive(any(), any(), any(), any(), any(), any()))
                .thenThrow(new FunctionNotFoundException("myfunc"));

        webClient.post()
                .uri("/v1/functions/myfunc:invoke")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(request)
                .exchange()
                .expectStatus().isNotFound();  // Function not found, but validation passed
    }

    @Test
    void validationError_hasCorrectFormat() {
        FunctionSpec spec = new FunctionSpec(
                "",    // blank name
                "",    // blank image
                null, null, null, null,
                -1,   // negative concurrency
                null, null, null,
                ExecutionMode.DEPLOYMENT, null, null, null
        );

        webClient.post()
                .uri("/v1/functions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(spec)
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("VALIDATION_ERROR")
                .jsonPath("$.message").isEqualTo("Request validation failed")
                .jsonPath("$.details").isArray()
                .jsonPath("$.details").isNotEmpty();
    }
}
