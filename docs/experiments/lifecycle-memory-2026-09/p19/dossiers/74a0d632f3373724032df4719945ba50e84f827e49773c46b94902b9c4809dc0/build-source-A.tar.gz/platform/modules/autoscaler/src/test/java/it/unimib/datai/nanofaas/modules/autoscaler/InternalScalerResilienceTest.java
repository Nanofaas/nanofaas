package it.unimib.datai.nanofaas.modules.autoscaler;

import it.unimib.datai.nanofaas.common.model.ExecutionMode;
import it.unimib.datai.nanofaas.common.model.FunctionSpec;
import it.unimib.datai.nanofaas.common.model.RuntimeMode;
import it.unimib.datai.nanofaas.common.model.ScalingConfig;
import it.unimib.datai.nanofaas.common.model.ScalingMetric;
import it.unimib.datai.nanofaas.common.model.ScalingStrategy;
import it.unimib.datai.nanofaas.controlplane.registry.ManagedDeploymentCoordinator;
import it.unimib.datai.nanofaas.controlplane.deployment.ManagedDeploymentTarget;
import it.unimib.datai.nanofaas.controlplane.deployment.ReplicaStatus;
import it.unimib.datai.nanofaas.controlplane.registry.DeploymentMetadata;
import it.unimib.datai.nanofaas.controlplane.registry.FunctionRegistry;
import it.unimib.datai.nanofaas.controlplane.registry.RegisteredFunction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InternalScalerResilienceTest {

    @Mock
    private FunctionRegistry registry;

    @Mock
    private ScalingMetricsReader metricsReader;

    @Mock
    private ManagedDeploymentCoordinator deploymentCoordinator;

    private InternalScaler scaler;

    @BeforeEach
    void setUp() {
        scaler = new InternalScaler(
                registry,
                metricsReader,
                deploymentCoordinator,
                new ScalingProperties(5000L, 1, 10),
                new ColdStartTracker()
        );
    }

    @Test
    void scalingLoop_continuesWhenOneFunctionHasInvalidMetricTarget() {
        RegisteredFunction broken = spec(
                "broken",
                new ScalingConfig(
                        ScalingStrategy.INTERNAL,
                        1,
                        10,
                        List.of(new ScalingMetric("queue_depth", null, null))
                )
        );
        RegisteredFunction healthy = spec(
                "healthy",
                new ScalingConfig(
                        ScalingStrategy.INTERNAL,
                        1,
                        10,
                        List.of(new ScalingMetric("queue_depth", "5", null))
                )
        );

        when(registry.listRegistered()).thenReturn(List.of(broken, healthy));
        when(deploymentCoordinator.getReplicaStatus(target(broken))).thenReturn(new ReplicaStatus(1, 1));
        when(deploymentCoordinator.getReplicaStatus(target(healthy))).thenReturn(new ReplicaStatus(1, 1));
        when(metricsReader.readMetric(eq("broken"), any())).thenReturn(10.0);
        when(metricsReader.readMetric(eq("healthy"), any())).thenReturn(15.0);

        scaler.scalingLoop();

        verify(deploymentCoordinator).setReplicas(target(healthy), 3);
    }

    private RegisteredFunction spec(String name, ScalingConfig scalingConfig) {
        return new RegisteredFunction(new FunctionSpec(
                name,
                "image:latest",
                List.of(),
                Map.of(),
                null,
                30000,
                4,
                100,
                3,
                "http://fn-" + name + ".default.svc:8080/invoke",
                ExecutionMode.DEPLOYMENT,
                RuntimeMode.HTTP,
                null,
                scalingConfig
        ), new DeploymentMetadata(ExecutionMode.DEPLOYMENT, ExecutionMode.DEPLOYMENT, "k8s", null));
    }
    private static ManagedDeploymentTarget target(RegisteredFunction function) {
        return new ManagedDeploymentTarget(function.name(), function.deploymentMetadata().deploymentBackend());
    }
}
