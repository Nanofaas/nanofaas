package it.unimib.datai.nanofaas.examples.romannumeral;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RomanNumeralApplication {
    public static void main(String[] args) {
        SpringApplication.run(RomanNumeralApplication.class, args);
    }
}
